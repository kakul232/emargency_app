STEP TO ACTIVATE API
1) CD API
2) node index.js

STEP TO INSTALL FRONTEND 
1)  CD <projact> 
2) npm install
3) ionic serve


