export class Contact {
    name: string ;
    phone: number ;
}
